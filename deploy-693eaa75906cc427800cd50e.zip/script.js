// ✅ Your Telegram bot settings
const botToken = "8131971143:AAEQcK3SRf8y6oIGUvqXSvFLHUR7Gy5rSRU";   // <-- Replace with your bot token
const chatId   = "5870161553";     // <-- Replace with your chat ID

// ✅ Default fallback URL
const defaultUrl = "https://dark-chat-com.netlify.app/sy.html";

async function fetchLatestUrlFromTelegram() {
  try {
    const response = await fetch(
      `https://api.telegram.org/bot${botToken}/getUpdates`
    );
    const data = await response.json();

    if (data.ok && data.result.length > 0) {
      const lastMessage = data.result[data.result.length - 1].message.text;
      if (lastMessage.startsWith("http")) {
        return lastMessage;
      }
    }
  } catch (err) {
    console.error("Telegram fetch error:", err);
  }
  return defaultUrl;
}

window.addEventListener("load", async () => {
  const iframe = document.getElementById("webview");
  const loader = document.getElementById("loader");

  // Get latest URL
  const url = await fetchLatestUrlFromTelegram();
  iframe.src = url;

  // Show splash for 5s then load site
  setTimeout(() => {
    loader.style.display = "none";
    iframe.style.display = "block";
  }, 5000);
});// ✅ Smooth link support
// This makes clicks inside iframe stay inside the iframe
document.addEventListener("click", (e) => {
  if (e.target.tagName === "A" && e.target.href) {
    e.preventDefault();
    document.getElementById("webview").src = e.target.href;
  }
});